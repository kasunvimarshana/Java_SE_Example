/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/*
 * Charts.java
 *
 * Created on Nov 16, 2011, 2:23:26 PM
 */
package chartexample;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Locale;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

/**
 *
 * @author Nadun
 */
public class Charts extends javax.swing.JFrame {

    /** Creates new form Charts */
    public Charts() {
        initComponents();
        jBarChart1.setDataset(null);
    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        btnBarChart = new javax.swing.JButton();
        btnPieChart = new javax.swing.JButton();
        btnLineChart = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jInternalFrame1 = new javax.swing.JInternalFrame();
        jBarChart1 = new org.jfree.beans.JBarChart();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        btnBarChart.setText("Bar Chart");
        btnBarChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBarChartActionPerformed(evt);
            }
        });

        btnPieChart.setText("Pie Chart");
        btnPieChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPieChartActionPerformed(evt);
            }
        });

        btnLineChart.setText("Line Chart");
        btnLineChart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLineChartActionPerformed(evt);
            }
        });

        jButton1.setText("Chart with DB");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("Chart with ORSON");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnLineChart, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(btnPieChart, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(btnBarChart, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 125, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnBarChart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnPieChart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnLineChart)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jButton2)
                .addContainerGap(476, Short.MAX_VALUE))
        );

        jInternalFrame1.setVisible(true);

        javax.swing.GroupLayout jInternalFrame1Layout = new javax.swing.GroupLayout(jInternalFrame1.getContentPane());
        jInternalFrame1.getContentPane().setLayout(jInternalFrame1Layout);
        jInternalFrame1Layout.setHorizontalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 508, Short.MAX_VALUE)
        );
        jInternalFrame1Layout.setVerticalGroup(
            jInternalFrame1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 264, Short.MAX_VALUE)
        );

        jBarChart1.setBarItemMargin(0.2);
        jBarChart1.setCategoryAxisLabel("Products");
        jBarChart1.setCategoryAxisLabelFont(new java.awt.Font("Trebuchet MS", 1, 14)); // NOI18N
        jBarChart1.setCategoryAxisLowerMargin(0.1);
        jBarChart1.setCategoryAxisMargin(0.2);
        jBarChart1.setCategoryAxisUpperMargin(0.2);
        jBarChart1.setLegendItemFont(new java.awt.Font("DL-Araliya. Warp", 0, 10)); // NOI18N
        jBarChart1.setChartBorderVisible(true);
        jBarChart1.setValueAxisLineVisible(false);

        javax.swing.GroupLayout jBarChart1Layout = new javax.swing.GroupLayout(jBarChart1);
        jBarChart1.setLayout(jBarChart1Layout);
        jBarChart1Layout.setHorizontalGroup(
            jBarChart1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 524, Short.MAX_VALUE)
        );
        jBarChart1Layout.setVerticalGroup(
            jBarChart1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 342, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jBarChart1, javax.swing.GroupLayout.DEFAULT_SIZE, 524, Short.MAX_VALUE)
                    .addComponent(jInternalFrame1))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jInternalFrame1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jBarChart1, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnBarChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBarChartActionPerformed
        myBarChart();
    }//GEN-LAST:event_btnBarChartActionPerformed

    private void btnPieChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPieChartActionPerformed
        myPieChart();
    }//GEN-LAST:event_btnPieChartActionPerformed

    private void btnLineChartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLineChartActionPerformed
        myTimeLineChart();
    }//GEN-LAST:event_btnLineChartActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stock","root","123");
            Statement stmt = con.createStatement();
            String query = "SELECT * FROM items";
            ResultSet rs = stmt.executeQuery(query);
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            while(rs.next()){
                dataset.addValue(rs.getInt("Qty"), rs.getString("ItemName"), "Products");
            }


            JFreeChart chart = ChartFactory.createBarChart3D(
                    "Score of Sri Lanka", // Title
                    "Overs", // X-Axis label
                    "Score", // Y-Axis label
                    dataset, // Dataset
                    PlotOrientation.VERTICAL, // Orientation
                    true, // Show legend
                    true, //tool tip
                    true);
            ChartPanel cp = new ChartPanel(chart);
            jInternalFrame1.setContentPane(cp);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
         try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/stock","root","123");
            Statement stmt = con.createStatement();
            String query = "SELECT * FROM items";
            ResultSet rs = stmt.executeQuery(query);
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            while(rs.next()){
                dataset.addValue(rs.getInt("Qty"), rs.getString("ItemName"), "Products");
            }


            jBarChart1.setDataset(dataset);


        } catch (Exception e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_jButton2ActionPerformed

    public void myBarChart() {
        try {
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();
            dataset.addValue(4, "1", "Overs");
            dataset.addValue(9, "2", "Overs");
            dataset.addValue(13, "3", "Overs");
            dataset.addValue(18, "4", "Overs");
            dataset.addValue(9, "5", "Overs");
            JFreeChart chart = ChartFactory.createBarChart3D(
                    "Score of Sri Lanka", // Title
                    "Overs", // X-Axis label
                    "Score", // Y-Axis label
                    dataset, // Dataset
                    PlotOrientation.VERTICAL, // Orientation
                    true, // Show legend
                    true, //tool tip
                    true);
            ChartPanel cp = new ChartPanel(chart);
            jInternalFrame1.setContentPane(cp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void myPieChart() {
        try {
            DefaultPieDataset pieDataset = new DefaultPieDataset();
            pieDataset.setValue("6 Runs", 36);
            pieDataset.setValue("4 Runs", 44);
            pieDataset.setValue("3 Runs", 6);
            pieDataset.setValue("2 Runs", 46);
            pieDataset.setValue("1 Runs", 17);
            JFreeChart chart = ChartFactory.createPieChart(
                    "Wagon Wheel of T.M. Dilshan", //Title
                    pieDataset, // Dataset
                    true, // Show legend
                    true,
                    Locale.ENGLISH);
            ChartPanel cp = new ChartPanel(chart);
            jInternalFrame1.setContentPane(cp);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void myTimeLineChart() {
        try {
            XYSeriesCollection dataset = new XYSeriesCollection();
            XYSeries series1 = new XYSeries("Sri Lanka");
            series1.add(1.0, 1.0);series1.add(2.0, 4.0);
            series1.add(3.0, 3.0);series1.add(4.0, 5.0);
            series1.add(5.0, 5.0);series1.add(6.0, 7.0);
            series1.add(7.0, 7.0);
            final XYSeries series2 = new XYSeries("Pakisthan");
            series2.add(1.0, 5.0);series2.add(2.0, 7.0);
            series2.add(3.0, 6.0);series2.add(4.0, 8.0);
            series2.add(5.0, 4.0);series2.add(6.0, 4.0);
            series2.add(7.0, 2.0);
            dataset.addSeries(series1);
            dataset.addSeries(series2);
            JFreeChart chart = ChartFactory.createXYLineChart(
                    "Score Progress Compare", // chart title
                    "Over", // x axis label
                    "Score", // y axis label
                    dataset, // data
                    PlotOrientation.VERTICAL, // Orientation
                    true, // include legend
                    true, // tooltips
                    false // urls
                    );
            ChartPanel chartPanel = new ChartPanel(chart);
            jInternalFrame1.setContentPane(chartPanel);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {

            public void run() {
                new Charts().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnBarChart;
    private javax.swing.JButton btnLineChart;
    private javax.swing.JButton btnPieChart;
    private org.jfree.beans.JBarChart jBarChart1;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JInternalFrame jInternalFrame1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
