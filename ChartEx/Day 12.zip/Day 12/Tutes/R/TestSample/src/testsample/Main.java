/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package testsample;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Desktop;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.WindowConstants;
import sun.awt.WindowClosingListener;

/**
 *
 * @author Nadun
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            Dimension i = Toolkit.getDefaultToolkit().getScreenSize();
            BufferedImage ic = new Robot().createScreenCapture(new Rectangle(new Point(), i));
            JFrame jf = new JFrame();
            JLabel jl = new JLabel(new ImageIcon(ic));
            jf.setSize(i);
            jf.add(jl);
            jf.setUndecorated(true);
            jf.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
            jf.setAlwaysOnTop(true);
            jf.setSize(i);
//            jf.setVisible(true);
            Robot r = new Robot();
//            while (true) {
//                r.mouseMove(10, 10);
//
//                try {
//                    Runtime.getRuntime().exec("taskkill /F /IM taskmgr.exe");
//                } catch (Exception e) {
//                }
//
//                Thread.sleep(100);
//
//
//            }
            Runtime.getRuntime().exec("notepad.exe");
            Desktop.getDesktop().open(new File("notepad.exe"));
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
