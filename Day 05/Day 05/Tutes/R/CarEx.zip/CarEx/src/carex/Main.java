/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package carex;

/**
 *
 * @author Nadun
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new CarGame().setVisible(true);
    }

}
