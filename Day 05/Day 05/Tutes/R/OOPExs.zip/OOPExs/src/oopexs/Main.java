/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oopexs;

/**
 *
 * @author Nadun
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
//        Bike myBike = new Bike("WP VY 0509", 0, new Person("883543696V","Nadun","Piliyandala",22));
//        System.out.println(myBike.increamentGear(3));
//        System.out.println(myBike.increamentGear(1, true));
//        System.out.println(myBike.increamentGear(1, false));

        Bike b = new Bike("WP VY 0509");
    }

}
