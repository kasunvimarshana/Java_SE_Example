/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package oopexs;

/**
 *
 * @author Nadun
 */
public class Person {

    String nic;
    String name;
    String address;
    int age;

    Person(String nic, String name, String address, int age) {
        this.nic = nic;
        this.name = name;
        this.address = address;
        this.age = age;
    }

}
