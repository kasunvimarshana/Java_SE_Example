
package shynsgame;

public class Main {

    public static void main(String[] args) {
        new CarRace().setVisible(true);
    }

}
