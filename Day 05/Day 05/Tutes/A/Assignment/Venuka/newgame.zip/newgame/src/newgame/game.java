

package newgame;

import java.awt.event.KeyEvent;
import javax.swing.JOptionPane;

public class game extends javax.swing.JFrame {

 


    public boolean crashed = false;
    public int speed = 1;
    public int score = 0;
    public game() {
        initComponents();
        my();
    }

    public void my(){
        new Thread(new Runnable() {

            public void run() {
                while (!crashed) {
                    try {
                        Thread.sleep(1);
                        if (lblse111.getX() >= getWidth()-150) {
                            lblse111.setLocation((lblse22.getX()+speed) - lblse111.getWidth(), lblse111.getY());
                        } else {
                            lblse111.setLocation(lblse111.getX()+ speed, lblse111.getY() );
                        }
                        if (lblse22.getX() >= getWidth()-150) {
                            lblse22.setLocation((lblse33.getX()+ speed)-lblse22.getWidth(), lblse22.getY()  );
                        } else {
                            lblse22.setLocation(lblse22.getX()+ speed, lblse22.getY() );
                        }
                        if (lblse33.getX() >= getWidth()-150) {
                            lblse33.setLocation((lblse111.getX()+ speed)-lblse33.getWidth(), lblse33.getY()  );
                        } else {
                            lblse33.setLocation(lblse33.getX()+ speed, lblse33.getY() );
                        }
                        
                       

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }).start();
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        lblsea2 = new javax.swing.JLabel();
        lblsea111 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        lblboat = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        lblen1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblen2 = new javax.swing.JLabel();
        lblscore = new javax.swing.JLabel();
        lblrock = new javax.swing.JLabel();
        lblmarks = new javax.swing.JLabel();
        lblse111 = new javax.swing.JLabel();
        lblse22 = new javax.swing.JLabel();
        lblse33 = new javax.swing.JLabel();

        lblsea2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/seamy2.png"))); // NOI18N

        lblsea111.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/SEA.png"))); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                formKeyPressed(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1309, 0, -1, 322));

        lblboat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/boat2.gif"))); // NOI18N
        getContentPane().add(lblboat, new org.netbeans.lib.awtextra.AbsoluteConstraints(530, 90, 240, -1));
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1260, 140, -1, -1));

        lblen1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/boat5.gif"))); // NOI18N
        getContentPane().add(lblen1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, 130, 130));
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 110, -1, -1));

        lblen2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/boat5.gif"))); // NOI18N
        getContentPane().add(lblen2, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 140, 160, 130));

        lblscore.setFont(new java.awt.Font("Comic Sans MS", 0, 24)); // NOI18N
        lblscore.setText("Score:");
        getContentPane().add(lblscore, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 300, 80, 50));

        lblrock.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/1216137609217389073Angelo_Gemmi_stone.svg.med.png"))); // NOI18N
        lblrock.setText("jLabel4");
        getContentPane().add(lblrock, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 260, 190, 90));

        lblmarks.setBackground(new java.awt.Color(255, 255, 51));
        lblmarks.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        getContentPane().add(lblmarks, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 290, 80, 50));

        lblse111.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/SEA.png"))); // NOI18N
        lblse111.setText("jLabel1");
        getContentPane().add(lblse111, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 600, -1));

        lblse22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/SEA.png"))); // NOI18N
        getContentPane().add(lblse22, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 0, -1, -1));

        lblse33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/newgame/SEA.png"))); // NOI18N
        getContentPane().add(lblse33, new org.netbeans.lib.awtextra.AbsoluteConstraints(1200, 0, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void formKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_formKeyPressed
//        System.out.println(evt.getKeyCode());
               int key = evt.getKeyCode();
        switch (key) {
            
            case 37:
            lblboat.setBounds(lblboat.getX()-5, lblboat.getY(),
                    lblboat.getWidth(),lblboat.getHeight());
            break;
           case 39:
               
            lblboat.setBounds(lblboat.getX()+5, lblboat.getY(),
                    lblboat.getWidth(),lblboat.getHeight());
                  break;
            case 38:
               lblboat.setLocation(  lblboat.getX(),lblboat.getY()-1);
                  break;
            case 40:
                  lblboat.setLocation(  lblboat.getX(),lblboat.getY()+1);
                   break;
            case 32:
                  speed=0;
                  break;
            case 18:
              lblboat.setLocation(  lblboat.getX()-5,lblboat.getY()-1);
                  break;
                 case 17:
              lblboat.setLocation(  lblboat.getX()-5,lblboat.getY()+1);
                 break;
                
        }

         if (lblboat.getX()==lblen1.getX())
             {
                 lblen1.setVisible(false);
                 score=score+50;
            
                 
         }


        if (lblboat.getX()==lblen2.getX())
             {
               lblen2.setVisible(false);
               score=score+50;
              
         }


         if (lblboat.getY()==lblrock.getY())
             {
               lblboat.setVisible(false);
               JOptionPane.showMessageDialog(null,"OOPs you Loose!!!!");

         }
 if (score==50)
                lblmarks.setText("50");
       if(score == 100)
                lblmarks.setText("100");
        
         if (score==100){
        JOptionPane.showMessageDialog(null,"Congradulations you won the game!!!!");
    }//GEN-LAST:event_formKeyPressed
    

    }


    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new game().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lblboat;
    private javax.swing.JLabel lblen1;
    private javax.swing.JLabel lblen2;
    private javax.swing.JLabel lblmarks;
    private javax.swing.JLabel lblrock;
    private javax.swing.JLabel lblscore;
    private javax.swing.JLabel lblse111;
    private javax.swing.JLabel lblse22;
    private javax.swing.JLabel lblse33;
    private javax.swing.JLabel lblsea111;
    private javax.swing.JLabel lblsea2;
    // End of variables declaration//GEN-END:variables

}